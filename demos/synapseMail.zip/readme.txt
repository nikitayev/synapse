-------------------------------------------------------------------------------

                synapseMail (c) 2004 Lubos Dusanic

-------------------------------------------------------------------------------

Introdution
synapseMail is a lightweight, stable, easy to configure and easy to manage
mail server. It performs all basic e-mail tasks, and much more. It is fully
functional mail system, which supports the most popular mail protocols: SMTP,
POP3. It has a built-in management console, to give administrators quick and
easy access to the server configuration.

Features
- support of multiple local domains
- support of multiple email addresses for a local user
- relaying of mail according to IP addresses
- supports basic attachment and anti-spam filters (plus you can specify
  domains of trusted connections)
- supports message size limits
- can listen on all local IP addresses
- supports verifying of senders of arrived messages
- support server - side logging
